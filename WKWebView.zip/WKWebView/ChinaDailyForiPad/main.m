//
//  main.m
//  ChinaDailyForiPad
//
//  Created by 王双龙 on 2018/4/4.
//  Copyright © 2018年 王双龙. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
